<< Leitura Arquivo CSV Node >>

>> Instalações necessárias no projeto:

npm install fs

npm install readline-sync

>> Para ler CSVs e gravar dados no BD

npm run start

CTRL+C para encerrar arquivo bat

>> Referências:

Node — Como manipular arquivos usando FS, Thiago Silva, https://blog.toolboxdevops.cloud/node-crud-arquivos-142e3fb1892d

4 ways to read file line by line in Node.js, Geshan Manandhar, https://geshan.com.np/blog/2021/10/nodejs-read-file-line-by-line/
