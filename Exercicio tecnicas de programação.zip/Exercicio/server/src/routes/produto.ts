import { Router } from "express";
import ProdutoController from "../controllers/ProdutoController";
const routes = Router();

routes.post('/',()=>{ProdutoController.create});
routes.get('/',()=>{ProdutoController.list});
routes.delete('/',()=>{ProdutoController.delete});
routes.put('/',()=>{ProdutoController.update});

export default routes;