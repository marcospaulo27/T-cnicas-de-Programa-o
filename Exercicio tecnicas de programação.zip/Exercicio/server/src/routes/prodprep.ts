import { Router } from "express";
import ProdPredController from "../controllers/ProdPredController";
const routes = Router();

routes.post('/',()=>{ProdPredController.create});
routes.get('/', ()=>{ProdPredController.list});
routes.delete('/',()=>{ProdPredController.delete});

export default routes;