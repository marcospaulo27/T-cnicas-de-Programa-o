import { Router } from "express";
import PreparacaoController from "../controllers/PreparacaoController";
const routes = Router();

routes.post('/',()=>{PreparacaoController.create});
routes.get('/', ()=>{PreparacaoController.list});
routes.delete('/',()=>{PreparacaoController.delete});
routes.put('/',()=> {PreparacaoController.update});

export default routes;