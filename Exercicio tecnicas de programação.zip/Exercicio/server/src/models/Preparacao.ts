class Preparacao {
    id: number;
    pre_descricao: string;
    constructor(id:number,pre_descricao:string){
        this.id = id;
        this.pre_descricao = pre_descricao;
    }
}

export default Preparacao;