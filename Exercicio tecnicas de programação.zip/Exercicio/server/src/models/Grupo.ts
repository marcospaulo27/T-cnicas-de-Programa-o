class Grupo {
    id: number;
    gru_descricao: string;
    constructor(id:number,gru_descricao:string){
        this.id = id;
        this.gru_descricao = gru_descricao;
    }
}

export default Grupo;