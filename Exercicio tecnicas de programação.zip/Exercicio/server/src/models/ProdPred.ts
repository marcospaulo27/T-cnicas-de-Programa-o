class ProdPrep {

    id:number;
    preparacao:number;
    energia:number;
    proteina:number;
    lipidio:number;
    carboidrato:number;
    fibra:number;


    constructor(id:number,preparacao:number,energia:number,proteina:number,lipidio:number,carboidrato:number,fibra:number){
        this.id = id;
        this.preparacao = preparacao;
        this.energia = energia;
        this.proteina=proteina;
        this.lipidio=lipidio;
        this.carboidrato=carboidrato;
        this.fibra=fibra;
    }
}

export default ProdPrep;